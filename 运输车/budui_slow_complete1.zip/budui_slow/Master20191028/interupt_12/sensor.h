#ifndef __SENSOR_H__
#define __SENSOR_H__

//#include <VL53L1X.h>

//class MPU6050
//{
//  public:
//   MPU6050();
//   ~MPU6050();
//   void Initial();
//   void DataGet();
//   void DataSend();
//  private:
//    int16_t AcX,AcY,AcZ,Te,GyX,GyY,GyZ;
//    int16_t range;
//    String ColorState;
//   // VL53L1X *sensor;
//};

#endif
