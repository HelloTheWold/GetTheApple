#ifndef __SEE_H__
#define __SEE_H__

void IoInitial();						//初始化io
void StepMotorEnable();					//步进电机使能
void StepMotorDisable();				//步进电机去使能



void nround();   //
void sround();
void 

void StepMotorMoveOneStep();          //步进电机运动一下

#endif